
import yaml
from pathlib import Path

def generate_client(spec, out):
    out.mkdir(exist_ok=True, parents=True)
    (out/"__init__.py").write_text("")
    # basic async client
    client = """import httpx

class OrigoAsyncClient:
    def __init__(self, base_url, api_key=None):
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self.client = httpx.AsyncClient(base_url=base_url, headers=headers)

    async def request(self, method, path, **kwargs):
        r = await self.client.request(method, path, **kwargs)
        r.raise_for_status()
        return r.json()
"""
    (out/"client.py").write_text(client)

    paths = spec.get("paths", {})
    groups = {}
    for p, ops in paths.items():
        seg = p.strip("/").split("/")[0]
        groups.setdefault(seg, []).append((p, ops))

    for seg, items in groups.items():
        cls = seg.title().replace("-", "")
        buf = [f"from .client import OrigoAsyncClient\n\nclass {cls}API:\n    def __init__(self, client: OrigoAsyncClient):\n        self.client = client\n"]
        for p, ops in items.items() if isinstance(items, dict) else items:
            for method, detail in ops.items():
                name = detail.get("summary", f"{method}_{p}").replace(" ", "_")
                buf.append(f"    async def {name}(self, **kwargs):\n        return await self.client.request('{method.upper()}', '{p}', **kwargs)\n")
        (out/f"{seg}_api.py").write_text("\n".join(buf))


def generate_server(spec, out):
    out.mkdir(exist_ok=True, parents=True)
    (out/"__init__.py").write_text("")
    # basic FastAPI app
    app = ["from fastapi import APIRouter\nrouter = APIRouter()\n"]
    paths = spec.get("paths", {})
    for p, ops in paths.items():
        for method, detail in ops.items():
            func = detail.get("summary", f"{method}_{p}").replace(" ", "_")
            app.append(f"@router.{method}('{p}')\nasync def {func.replace('/', '_')}(payload: dict | None = None):\n    return {{'message': 'stub'}}\n")
    (out/"routes.py").write_text("\n".join(app))


def main(openapi_file, client_out, server_out):
    spec = yaml.safe_load(Path(openapi_file).read_text())
    generate_client(spec, Path(client_out))
    generate_server(spec, Path(server_out))

if __name__ == "__main__":
    print("Usage: python autogen.py <openapi.yaml> <client_dir> <server_dir>")
