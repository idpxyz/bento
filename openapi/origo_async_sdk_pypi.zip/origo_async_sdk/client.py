
import httpx

class OrigoAsyncClient:
    def __init__(self, base_url: str, api_key: str = None, timeout: float = 30.0):
        self.base_url = base_url.rstrip("/")
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self.client = httpx.AsyncClient(base_url=self.base_url, headers=headers, timeout=timeout)

    async def get(self, path: str, **kwargs):
        r = await self.client.get(path, **kwargs)
        r.raise_for_status()
        return r.json()

    async def post(self, path: str, json=None, files=None, **kwargs):
        r = await self.client.post(path, json=json, files=files, **kwargs)
        r.raise_for_status()
        return r.json()

    async def put(self, path: str, json=None, **kwargs):
        r = await self.client.put(path, json=json, **kwargs)
        r.raise_for_status()
        return r.json()

    async def delete(self, path: str, **kwargs):
        r = await self.client.delete(path, **kwargs)
        r.raise_for_status()
        return r.json()

    async def close(self):
        await self.client.aclose()
