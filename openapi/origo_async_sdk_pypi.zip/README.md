
# Origo Async SDK

Async Python client for Origo PIM API.

## Installation
```bash
pip install origo-async-sdk
```

## Usage
```python
import asyncio
from origo_async_sdk import OrigoAsyncClient

async def main():
    client = OrigoAsyncClient("https://api.origo.com", api_key="xxx")
    res = await client.get("/products")
    print(res)
    await client.close()

asyncio.run(main())
```
