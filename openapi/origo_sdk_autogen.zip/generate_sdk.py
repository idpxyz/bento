
import yaml, os
from pathlib import Path

def generate_sdk(openapi_path: str, out_dir: str):
    spec = yaml.safe_load(Path(openapi_path).read_text())
    paths = spec.get("paths", {})

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out/"__init__.py").write_text("")

    client = """import httpx

class OrigoAsyncClient:
    def __init__(self, base_url, api_key=None):
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"]
        self.client = httpx.AsyncClient(base_url=base_url, headers=headers)

    async def request(self, method, path, **kwargs):
        r = await self.client.request(method, path, **kwargs)
        r.raise_for_status()
        return r.json()
"""
    (out/"client.py").write_text(client)

    # group paths by first segment
    groups = {}
    for p, ops in paths.items():
        seg = p.strip("/").split("/")[0]
        groups.setdefault(seg, []).append((p, ops))

    for seg, items in groups.items():
        fname = out/f"{seg}_api.py"
        buf = [f"from .client import OrigoAsyncClient

class {seg.title().replace('-', '')}API:
    def __init__(self, client: OrigoAsyncClient):
        self.client = client
"]
        for p, ops in items:
            for method in ops:
                mname = ops[method].get("summary", f"{method}_{p}").replace(" ", "_")
                buf.append(f"    async def {mname}(...):
        return await self.client.request('{method.upper()}', '{p}')
")
        fname.write_text("\n".join(buf))

if __name__ == '__main__':
    print("Usage: python generate_sdk.py <openapi.yaml> <output_dir>")
