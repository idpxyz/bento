
from .client import OrigoClient

class ProductAPI:
    def __init__(self, client: OrigoClient):
        self.client = client

    def list(self):
        return self.client.get("/products")

    def create(self, data):
        return self.client.post("/products", json=data)

    def get(self, product_id):
        return self.client.get(f"/products/{product_id}")

    def update(self, product_id, data):
        return self.client.put(f"/products/{product_id}", json=data)

    def delete(self, product_id):
        return self.client.delete(f"/products/{product_id}")
