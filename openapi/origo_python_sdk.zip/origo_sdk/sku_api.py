
from .client import OrigoClient

class SKUAPI:
    def __init__(self, client: OrigoClient):
        self.client = client

    def list(self, product_id):
        return self.client.get(f"/products/{product_id}/skus")

    def create(self, product_id, data):
        return self.client.post(f"/products/{product_id}/skus", json=data)
