
from .client import OrigoAsyncClient

class SKUAPI:
    def __init__(self, client: OrigoAsyncClient):
        self.client = client

    async def list(self, product_id):
        return await self.client.get(f"/products/{product_id}/skus")

    async def create(self, product_id, data):
        return await self.client.post(f"/products/{product_id}/skus", json=data)

    async def get(self, sku_id):
        return await self.client.get(f"/skus/{sku_id}")

    async def update(self, sku_id, data):
        return await self.client.put(f"/skus/{sku_id}", json=data)

    async def delete(self, sku_id):
        return await self.client.delete(f"/skus/{sku_id}")
