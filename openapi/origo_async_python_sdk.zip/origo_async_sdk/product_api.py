
from .client import OrigoAsyncClient

class ProductAPI:
    def __init__(self, client: OrigoAsyncClient):
        self.client = client

    async def list(self):
        return await self.client.get("/products")

    async def create(self, data):
        return await self.client.post("/products", json=data)

    async def get(self, product_id):
        return await self.client.get(f"/products/{product_id}")

    async def update(self, product_id, data):
        return await self.client.put(f"/products/{product_id}", json=data)

    async def delete(self, product_id):
        return await self.client.delete(f"/products/{product_id}")
